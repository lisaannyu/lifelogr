library(testthat)
library(lifelogr)

test_check("lifelogr")
