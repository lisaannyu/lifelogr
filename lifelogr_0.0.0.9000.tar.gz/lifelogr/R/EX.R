#' A subset of the data for one user for about one month, from 2017-01-19 to
#' 2017-02-17, containing \code{fitbit_daily}, \code{fitbit_intraday}, and 
#' \code{util} data
#' frames.
#'
#' @name EX
#' @docType data
#' @keywords data
#'
"EX"